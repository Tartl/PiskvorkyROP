﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Piskvorky
{
    public enum GameResult
    {
        Continue,
        Win,
        Draw,
    }
}
