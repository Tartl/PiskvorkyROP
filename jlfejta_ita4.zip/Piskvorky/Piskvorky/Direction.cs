﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace Piskvorky
{
    public enum Direction
    {
        Hor,
        Vert,
        Diag1,
        Diag2,
    }
}
